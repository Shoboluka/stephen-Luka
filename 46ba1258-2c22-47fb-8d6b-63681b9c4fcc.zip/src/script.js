function countTruthy(art){

  const truthyArray = arr.filter(Boolean);

  const truthyCount = truthyArray.length;

  return truethyCount;

  }

  countTruthy ({6, 3, 0, 30, 7]);



  function fizzBuzz(input){
  if (input%3==0){
  return "fizz";
  }else if (input%5==0){
  return "Buzz";
  }else if (input%3==0 && input%5==0){
  return "fizzBuzz";
  }else {
  return "invalid input";
  }
  }

  fizzBuzz(3);

   function sumMix(arr){

   for(let i = 0; i < values.length; i++) { if (typeof values[i] === 'string') { Number(values[i]) return Number(value
   s.reduce((i, j) => {return i + j})) } } 

   }
   sumMix ([9,3,'7','3']);


   function calculateGrade(marks){
   let sum=0;
   for(let I=0; I<marks.length; I++){
   sum +=marks[I];
   let average=sum/marks.length;
   if (average≥1 && average≤49){
   return "F";
   }else if (average≥50 && average≤59){
   return "E";
   }else if (average≥60 && average≤69){
   return "D";
   }else if (average≥70 && average≤79){
   return "C";
   }else if (average≥80 && average≤89){
   return "B";
   }else if (average≥90 && average≤100){
   return "A";
   }else{
   return "invalid input";
   }
   }
   calculateGrade([80, 80, 70]);

   function sumTeoSmallestNums(arr) {
     //Code here
       let ordered = numbers.sort(function(a,b){return a-b;});
       //  console.log(ordered);
         let result = 0;
             for (let i = 0; i < ordered.length; i++){
                   if (i===0){
                           result = result + ordered[0]; //2
                                   console.log(result);
                                         }
                                               if (i===1){
                                                       result = result + ordered[1]; //5
                                                               console.log(result);
                                                                     }
                                                                         }
                                                                             return result;
                                                                             };

                                                                             sumTwoSmallestNums([9, 5, 42, 2, 77]);



                                                                             function filter_list(l) {
                                                                               // Return a new array with the strings filtered out
                                                                                 var filt = l.filter(function(x) {
                                                                                     if (typeof(x) === 'number')
                                                                                           return x;
                                                                                             });
                                                                                               return filt;
                                                                                               }
                                                                                               filter list([1, 2, 'a', 'b']);
}